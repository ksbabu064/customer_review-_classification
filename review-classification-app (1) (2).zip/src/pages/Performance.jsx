import { useModel } from "../ml/useModel";
import StatCard from "../components/StatCard";
import Loading from "../components/Loading";

export default function Performance() {
  const state = useModel();
  if (state.status !== "ready") return <Loading />;

  const { accuracy, confusion, report, yTest } = state;
  const [[tn, fp], [fn, tp]] = confusion.matrix;
  const posReport = report[1];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-ink">Model Performance</h2>
        <p className="text-indigo-500 text-sm mt-1">
          Evaluated on a held-out test set of {yTest.length} reviews (80/20 split, seeded).
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Accuracy" value={`${(accuracy * 100).toFixed(2)}%`} accent />
        <StatCard label="Precision (Positive)" value={posReport.precision.toFixed(3)} />
        <StatCard label="Recall (Positive)" value={posReport.recall.toFixed(3)} />
        <StatCard label="F1-score (Positive)" value={posReport.f1.toFixed(3)} />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-indigo-100 p-6">
          <h3 className="font-semibold text-ink mb-4">Confusion Matrix</h3>
          <table className="w-full text-center border-collapse">
            <thead>
              <tr>
                <th></th>
                <th className="text-xs text-indigo-400 font-medium pb-2">Predicted: Negative</th>
                <th className="text-xs text-indigo-400 font-medium pb-2">Predicted: Positive</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th className="text-xs text-indigo-400 font-medium pr-2 text-right">Actual: Negative</th>
                <td className="bg-slate-100 rounded-lg p-4 font-bold text-lg text-ink">{tn}</td>
                <td className="bg-rose-50 rounded-lg p-4 font-bold text-lg text-rose-600">{fp}</td>
              </tr>
              <tr>
                <th className="text-xs text-indigo-400 font-medium pr-2 pt-2 text-right">Actual: Positive</th>
                <td className="bg-rose-50 rounded-lg p-4 pt-2 font-bold text-lg text-rose-600">{fn}</td>
                <td className="bg-indigo-50 rounded-lg p-4 pt-2 font-bold text-lg text-indigo-700">{tp}</td>
              </tr>
            </tbody>
          </table>
          <p className="text-xs text-indigo-300 mt-4">TN={tn} · FP={fp} · FN={fn} · TP={tp}</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-indigo-100 p-6">
          <h3 className="font-semibold text-ink mb-4">Classification Report</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs uppercase text-indigo-400 border-b border-indigo-100">
                <tr>
                  <th className="text-left py-2">Class</th>
                  <th className="text-right py-2">Precision</th>
                  <th className="text-right py-2">Recall</th>
                  <th className="text-right py-2">F1</th>
                  <th className="text-right py-2">Support</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-indigo-50">
                <ReportRow label="Negative (0)" row={report[0]} />
                <ReportRow label="Positive (1)" row={report[1]} />
                <ReportRow label="Macro Avg" row={report.macroAvg} bold />
                <ReportRow label="Weighted Avg" row={report.weightedAvg} bold />
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

function ReportRow({ label, row, bold }) {
  return (
    <tr className={bold ? "font-semibold" : ""}>
      <td className="py-2">{label}</td>
      <td className="text-right py-2">{row.precision.toFixed(3)}</td>
      <td className="text-right py-2">{row.recall.toFixed(3)}</td>
      <td className="text-right py-2">{row.f1.toFixed(3)}</td>
      <td className="text-right py-2">{row.support}</td>
    </tr>
  );
}
