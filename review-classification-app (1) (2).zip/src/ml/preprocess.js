import Papa from "papaparse";
import rawCsv from "../data/reviews.csv?raw";

let parsedCache = null;

export function loadRawRows() {
  if (parsedCache) return parsedCache;
  const result = Papa.parse(rawCsv, {
    header: true,
    dynamicTyping: false,
    skipEmptyLines: true,
  });
  parsedCache = result.data.filter((r) => r.review_text && r.sentiment);
  return parsedCache;
}

const STOPWORDS = new Set([
  "the","a","an","and","or","but","is","are","was","were","be","been","to","of","in","on",
  "for","with","at","by","from","up","about","into","over","after","i","you","your","it",
  "this","that","my","me","we","he","she","they","them","his","her","its","our","us","if",
  "so","as","do","does","did","have","has","had","will","would","can","could","just","not",
  "im","movie","film",
]);

export function tokenize(text) {
  return String(text)
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 1 && !STOPWORDS.has(t));
}

export function fitTfidf(tokenizedDocs, maxFeatures = 3000, minDocFreq = 2) {
  const docFreq = new Map();
  for (const tokens of tokenizedDocs) {
    const seen = new Set(tokens);
    for (const t of seen) docFreq.set(t, (docFreq.get(t) || 0) + 1);
  }

  const terms = [...docFreq.entries()]
    .filter(([, df]) => df >= minDocFreq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, maxFeatures)
    .map(([term]) => term);

  const vocab = new Map(terms.map((t, i) => [t, i]));
  const N = tokenizedDocs.length;
  const idf = new Float64Array(terms.length);
  terms.forEach((t, i) => {
    idf[i] = Math.log(N / (1 + docFreq.get(t))) + 1;
  });

  return { vocab, idf, terms };
}

export function transformTfidf(tokens, vocab, idf) {
  const vec = new Float64Array(vocab.size);
  const counts = new Map();
  for (const t of tokens) {
    if (vocab.has(t)) counts.set(t, (counts.get(t) || 0) + 1);
  }
  const total = tokens.length || 1;
  let normSq = 0;
  for (const [t, c] of counts) {
    const idx = vocab.get(t);
    const tf = c / total;
    const val = tf * idf[idx];
    vec[idx] = val;
    normSq += val * val;
  }
  const norm = Math.sqrt(normSq) || 1;
  for (let i = 0; i < vec.length; i++) vec[i] /= norm;
  return vec;
}

function seededRandom(seed) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return function () {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export function trainTestSplit(items, testSize = 0.2, seed = 42) {
  const rand = seededRandom(seed);
  const idx = items.map((_, i) => i);
  for (let i = idx.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [idx[i], idx[j]] = [idx[j], idx[i]];
  }
  const testCount = Math.round(items.length * testSize);
  const testIdx = idx.slice(0, testCount);
  const trainIdx = idx.slice(testCount);
  return { trainIdx, testIdx };
}

// Real customer (movie) reviews with real Positive/Negative sentiment labels.
export function buildDataset() {
  const rows = loadRawRows();
  const tokens = rows.map((r) => tokenize(r.review_text));
  const y = rows.map((r) => (r.sentiment.trim() === "Positive" ? 1 : 0));
  return { rows, tokens, y };
}
