export default function Loading({ label = "Training TF-IDF + Logistic Regression in your browser..." }) {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-indigo-500">
      <div className="w-10 h-10 border-4 border-indigo-200 border-t-accent rounded-full animate-spin mb-4" />
      <p className="text-sm font-medium">{label}</p>
    </div>
  );
}
