import { HashRouter, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import Dataset from "./pages/Dataset";
import ReviewClassification from "./pages/ReviewClassification";
import Performance from "./pages/Performance";
import { ModelProvider } from "./ml/useModel";

export default function App() {
  return (
    <ModelProvider>
      <HashRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/dataset" element={<Dataset />} />
            <Route path="/classify" element={<ReviewClassification />} />
            <Route path="/performance" element={<Performance />} />
          </Route>
        </Routes>
      </HashRouter>
    </ModelProvider>
  );
}
