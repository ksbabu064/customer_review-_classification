import { useState } from "react";
import { useModel, predictText } from "../ml/useModel";
import Loading from "../components/Loading";

const SAMPLE_POS = "This product exceeded my expectations. Great quality, fast shipping, and excellent customer service. Highly recommend!";
const SAMPLE_NEG = "Very disappointed with this purchase. It broke after two days and the customer support was unhelpful.";

export default function ReviewClassification() {
  const state = useModel();
  const [text, setText] = useState("");
  const [result, setResult] = useState(null);
  if (state.status !== "ready") return <Loading />;

  const { model, vocab, idf } = state;

  function handlePredict(e) {
    e.preventDefault();
    if (!text.trim()) return;
    setResult(predictText(model, vocab, idf, text));
  }

  function loadSample(sample) {
    setText(sample);
    setResult(null);
  }

  const posPct = result ? Math.round(result.proba[1] * 100) : null;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-ink">Review Classification</h2>
        <p className="text-indigo-500 text-sm mt-1">
          Paste a review and the trained Logistic Regression model classifies it as Positive or Negative.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <form onSubmit={handlePredict} className="bg-white rounded-xl shadow-sm border border-indigo-100 p-6 space-y-4">
          <textarea
            className="w-full h-48 border border-indigo-100 rounded-lg p-3 text-sm resize-none focus:outline-none focus:border-accent focus:ring-2 focus:ring-indigo-100"
            placeholder="Paste a customer review here..."
            value={text}
            onChange={(e) => { setText(e.target.value); setResult(null); }}
          />
          <div className="flex gap-2 text-xs">
            <button type="button" onClick={() => loadSample(SAMPLE_POS)}
              className="px-2.5 py-1 rounded-md border border-indigo-200 text-slate-500 hover:bg-slate-50">
              Load positive example
            </button>
            <button type="button" onClick={() => loadSample(SAMPLE_NEG)}
              className="px-2.5 py-1 rounded-md border border-indigo-200 text-slate-500 hover:bg-slate-50">
              Load negative example
            </button>
          </div>
          <button type="submit"
            className="w-full bg-accent hover:bg-indigo-800 transition-colors text-white font-semibold py-2.5 rounded-lg">
            Classify Review
          </button>
        </form>

        <div className="bg-white rounded-xl shadow-sm border border-indigo-100 p-6 flex flex-col items-center justify-center">
          {!result && (
            <p className="text-indigo-300 text-sm text-center">
              Paste a review and click <span className="font-medium">Classify Review</span>.
            </p>
          )}
          {result && (
            <div className="text-center space-y-3 w-full">
              <div className={`text-4xl font-bold ${result.prediction === 1 ? "text-indigo-700" : "text-rose-600"}`}>
                {result.prediction === 1 ? "Positive" : "Negative"}
              </div>
              <p className="text-indigo-400 text-sm">
                Positive probability: <strong>{posPct}%</strong>
              </p>
              <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                <div className="h-3 bg-gradient-to-r from-rose-500 to-indigo-600" style={{ width: `${posPct}%` }} />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
