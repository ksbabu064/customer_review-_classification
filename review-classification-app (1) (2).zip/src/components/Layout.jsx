import { NavLink, Outlet } from "react-router-dom";
const links = [
  { to: "/", label: "Dashboard", end: true },
  { to: "/dataset", label: "Dataset" },
  { to: "/classify", label: "Review Classification" },
  { to: "/performance", label: "Performance" },
];
export default function Layout() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-ink text-white">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-accent to-accent2 flex items-center justify-center font-bold">⭐</div>
            <div>
              <h1 className="font-semibold text-lg leading-tight">Customer Review Classification</h1>
              <p className="text-xs text-slate-400 leading-tight">TF-IDF + Logistic Regression · trained live in your browser</p>
            </div>
          </div>
          <nav className="flex gap-1">
            {links.map((l) => (
              <NavLink key={l.to} to={l.to} end={l.end}
                className={({ isActive }) => `px-3 py-2 rounded-md text-sm font-medium transition-colors ${isActive ? "bg-accent text-white" : "text-slate-300 hover:text-white hover:bg-white/10"}`}>
                {l.label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>
      <main className="flex-1 max-w-6xl w-full mx-auto px-6 py-8"><Outlet /></main>
      <footer className="text-center text-xs text-slate-400 py-6">
        Dataset: 1,200 real customer reviews (IMDB) · Model trained client-side with no backend
      </footer>
    </div>
  );
}
