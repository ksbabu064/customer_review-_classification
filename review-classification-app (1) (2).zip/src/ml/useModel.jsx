import { createContext, useContext, useEffect, useMemo, useState } from "react";
import {
  buildDataset, trainTestSplit, tokenize, fitTfidf, transformTfidf,
} from "./preprocess";
import { LogisticRegression, accuracyScore, confusionMatrix, classificationReport } from "./logisticRegression";

const ModelContext = createContext(null);

export function ModelProvider({ children }) {
  const [state, setState] = useState({ status: "training" });

  useEffect(() => {
    const timer = setTimeout(() => {
      const { rows, tokens, y } = buildDataset();
      const { trainIdx, testIdx } = trainTestSplit(rows, 0.2, 42);

      const trainTokens = trainIdx.map((i) => tokens[i]);
      const yTrain = trainIdx.map((i) => y[i]);
      const testTokens = testIdx.map((i) => tokens[i]);
      const yTest = testIdx.map((i) => y[i]);

      const { vocab, idf } = fitTfidf(trainTokens, 2000, 2);

      const XTrain = trainTokens.map((t) => transformTfidf(t, vocab, idf));
      const XTest = testTokens.map((t) => transformTfidf(t, vocab, idf));

      const model = new LogisticRegression({ lr: 0.5, epochs: 60, l2: 0.001 });
      model.fit(XTrain, yTrain);

      const yPred = model.predict(XTest);
      const accuracy = accuracyScore(yTest, yPred);
      const cm = confusionMatrix(yTest, yPred, [0, 1]);
      const report = classificationReport(yTest, yPred, [0, 1]);

      const total = rows.length;
      const posCount = y.filter((v) => v === 1).length;

      setState({
        status: "ready",
        model, vocab, idf, rows, tokens, y,
        trainIdx, testIdx, yTrain, yTest, yPred,
        accuracy, confusion: cm, report,
        total, posCount, negCount: total - posCount,
      });
    }, 30);
    return () => clearTimeout(timer);
  }, []);

  const value = useMemo(() => state, [state]);
  return <ModelContext.Provider value={value}>{children}</ModelContext.Provider>;
}

export function useModel() {
  const ctx = useContext(ModelContext);
  if (!ctx) throw new Error("useModel must be used within ModelProvider");
  return ctx;
}

export function predictText(model, vocab, idf, text) {
  const tokens = tokenize(text);
  const vec = transformTfidf(tokens, vocab, idf);
  const pred = model.predict([vec])[0];
  const proba = model.predictProba([vec])[0];
  return { prediction: pred, proba, tokenCount: tokens.length };
}
