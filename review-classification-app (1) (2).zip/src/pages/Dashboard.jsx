import {
  PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid,
} from "recharts";
import { useModel } from "../ml/useModel";
import StatCard from "../components/StatCard";
import Loading from "../components/Loading";

const COLORS = ["#4338ca", "#e11d48"];

export default function Dashboard() {
  const state = useModel();
  if (state.status !== "ready") return <Loading />;

  const { total, posCount, negCount, accuracy, rows } = state;

  const pieData = [
    { name: "Positive", value: posCount },
    { name: "Negative", value: negCount },
  ];

  const avgLenPos = rows.filter((r) => r.sentiment.trim() === "Positive").reduce((s, r) => s + r.review_text.length, 0) / posCount;
  const avgLenNeg = rows.filter((r) => r.sentiment.trim() === "Negative").reduce((s, r) => s + r.review_text.length, 0) / negCount;
  const lengthData = [
    { name: "Positive", avgChars: Math.round(avgLenPos) },
    { name: "Negative", avgChars: Math.round(avgLenNeg) },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-ink">Dashboard</h2>
        <p className="text-indigo-500 text-sm mt-1">Overview of {total.toLocaleString()} real customer reviews.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Reviews" value={total.toLocaleString()} />
        <StatCard label="Positive" value={`${posCount} (${Math.round((posCount / total) * 100)}%)`} />
        <StatCard label="Test Accuracy" value={`${(accuracy * 100).toFixed(1)}%`} accent />
        <StatCard label="Negative" value={negCount} />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-indigo-100 p-5">
          <h3 className="font-semibold text-ink mb-4">Sentiment Split</h3>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90}
                label={(entry) => `${entry.name}: ${entry.value}`}>
                {pieData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-indigo-100 p-5">
          <h3 className="font-semibold text-ink mb-4">Avg Review Length (characters)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={lengthData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e7ff" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="avgChars" fill="#4338ca" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
