// Binary Logistic Regression trained with mini-batch gradient descent on
// TF-IDF feature vectors. No external ML library; pure JS, runs client-side.

function sigmoid(z) {
  return 1 / (1 + Math.exp(-z));
}

export class LogisticRegression {
  constructor({ lr = 0.5, epochs = 60, l2 = 0.001 } = {}) {
    this.lr = lr;
    this.epochs = epochs;
    this.l2 = l2;
    this.weights = null;
    this.bias = 0;
  }

  fit(X, y) {
    const n = X.length;
    const nFeatures = X[0].length;
    this.weights = new Float64Array(nFeatures);
    this.bias = 0;

    for (let epoch = 0; epoch < this.epochs; epoch++) {
      const gradW = new Float64Array(nFeatures);
      let gradB = 0;

      for (let i = 0; i < n; i++) {
        const x = X[i];
        let z = this.bias;
        for (let j = 0; j < nFeatures; j++) z += this.weights[j] * x[j];
        const pred = sigmoid(z);
        const error = pred - y[i];
        for (let j = 0; j < nFeatures; j++) {
          if (x[j] !== 0) gradW[j] += error * x[j];
        }
        gradB += error;
      }

      for (let j = 0; j < nFeatures; j++) {
        this.weights[j] -= this.lr * (gradW[j] / n + this.l2 * this.weights[j]);
      }
      this.bias -= this.lr * (gradB / n);
    }
    return this;
  }

  _scoreOne(x) {
    let z = this.bias;
    for (let j = 0; j < x.length; j++) {
      if (x[j] !== 0) z += this.weights[j] * x[j];
    }
    return sigmoid(z);
  }

  predict(X) {
    return X.map((x) => (this._scoreOne(x) >= 0.5 ? 1 : 0));
  }

  predictProba(X) {
    return X.map((x) => {
      const p1 = this._scoreOne(x);
      return { 0: 1 - p1, 1: p1 };
    });
  }
}

// ---- Classification metrics ----

export function accuracyScore(yTrue, yPred) {
  let correct = 0;
  for (let i = 0; i < yTrue.length; i++) if (yTrue[i] === yPred[i]) correct++;
  return correct / yTrue.length;
}

export function confusionMatrix(yTrue, yPred, labels = [0, 1]) {
  const matrix = labels.map(() => labels.map(() => 0));
  const indexOf = new Map(labels.map((l, i) => [l, i]));
  for (let i = 0; i < yTrue.length; i++) {
    const r = indexOf.get(yTrue[i]);
    const c = indexOf.get(yPred[i]);
    if (r !== undefined && c !== undefined) matrix[r][c]++;
  }
  return { matrix, labels };
}

export function classificationReport(yTrue, yPred, labels = [0, 1]) {
  const report = {};
  let totalSupport = 0;
  let weightedPrecision = 0, weightedRecall = 0, weightedF1 = 0;
  let macroPrecision = 0, macroRecall = 0, macroF1 = 0;

  for (const label of labels) {
    let tp = 0, fp = 0, fn = 0, support = 0;
    for (let i = 0; i < yTrue.length; i++) {
      if (yTrue[i] === label) support++;
      if (yPred[i] === label && yTrue[i] === label) tp++;
      if (yPred[i] === label && yTrue[i] !== label) fp++;
      if (yPred[i] !== label && yTrue[i] === label) fn++;
    }
    const precision = tp + fp === 0 ? 0 : tp / (tp + fp);
    const recall = tp + fn === 0 ? 0 : tp / (tp + fn);
    const f1 = precision + recall === 0 ? 0 : (2 * precision * recall) / (precision + recall);

    report[label] = { precision, recall, f1, support };
    totalSupport += support;
    weightedPrecision += precision * support;
    weightedRecall += recall * support;
    weightedF1 += f1 * support;
    macroPrecision += precision;
    macroRecall += recall;
    macroF1 += f1;
  }

  report.accuracy = accuracyScore(yTrue, yPred);
  report.macroAvg = {
    precision: macroPrecision / labels.length,
    recall: macroRecall / labels.length,
    f1: macroF1 / labels.length,
    support: totalSupport,
  };
  report.weightedAvg = {
    precision: weightedPrecision / totalSupport,
    recall: weightedRecall / totalSupport,
    f1: weightedF1 / totalSupport,
    support: totalSupport,
  };

  return report;
}
