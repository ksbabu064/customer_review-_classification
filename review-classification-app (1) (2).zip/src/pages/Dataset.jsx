import { useMemo, useState } from "react";
import { useModel } from "../ml/useModel";
import Loading from "../components/Loading";

const PAGE_SIZE = 10;

export default function Dataset() {
  const state = useModel();
  const [page, setPage] = useState(0);
  const [filter, setFilter] = useState("all");
  if (state.status !== "ready") return <Loading />;

  const { rows } = state;
  const filtered = useMemo(() => {
    if (filter === "pos") return rows.filter((r) => r.sentiment.trim() === "Positive");
    if (filter === "neg") return rows.filter((r) => r.sentiment.trim() === "Negative");
    return rows;
  }, [rows, filter]);

  const pageCount = Math.ceil(filtered.length / PAGE_SIZE);
  const pageRows = filtered.slice(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE);

  function changeFilter(f) {
    setFilter(f);
    setPage(0);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-ink">Dataset</h2>
          <p className="text-indigo-500 text-sm mt-1">Real customer reviews ({rows.length.toLocaleString()} total).</p>
        </div>
        <div className="flex gap-1 bg-white border border-indigo-100 rounded-lg p-1">
          {[{ key: "all", label: "All" }, { key: "pos", label: "Positive" }, { key: "neg", label: "Negative" }].map((f) => (
            <button key={f.key} onClick={() => changeFilter(f.key)}
              className={`px-3 py-1.5 text-sm rounded-md font-medium transition-colors ${
                filter === f.key ? "bg-accent text-white" : "text-slate-600 hover:bg-slate-100"
              }`}>
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-indigo-100 divide-y divide-indigo-50">
        {pageRows.map((r, i) => (
          <div key={i} className="px-5 py-3 flex items-start gap-3">
            <span className={`shrink-0 mt-0.5 inline-block px-2 py-0.5 rounded-full text-xs font-medium ${
              r.sentiment.trim() === "Positive" ? "bg-indigo-100 text-indigo-700" : "bg-rose-100 text-rose-700"
            }`}>
              {r.sentiment.trim()}
            </span>
            <p className="text-sm text-slate-700 leading-snug line-clamp-3">{r.review_text.slice(0, 260)}{r.review_text.length > 260 ? "…" : ""}</p>
          </div>
        ))}
        <div className="flex items-center justify-between px-5 py-3 text-sm text-indigo-400">
          <span>Showing {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, filtered.length)} of {filtered.length}</span>
          <div className="flex gap-2">
            <button onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0}
              className="px-3 py-1 rounded-md border border-indigo-200 disabled:opacity-40">Prev</button>
            <button onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))} disabled={page >= pageCount - 1}
              className="px-3 py-1 rounded-md border border-indigo-200 disabled:opacity-40">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
}
