export default function StatCard({ label, value, sub, accent = false }) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-indigo-100 p-5">
      <p className="text-xs uppercase tracking-wide text-indigo-500 font-medium">{label}</p>
      <p className={`text-3xl font-bold mt-1 ${accent ? "text-accent" : "text-ink"}`}>{value}</p>
      {sub && <p className="text-xs text-indigo-400 mt-1">{sub}</p>}
    </div>
  );
}
